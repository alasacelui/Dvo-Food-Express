<?php include 'header.php' ?>
<br><br><br><br>
<div class="container ">
<center><h1 class="text-primary">About Us</h1></center><br>
<h3 class="text-info">It is known globally that, in today’s market, it is extremely difficult to start a new small-scale 
business and live-through the competition from the well-established and settled owners. In fast paced time 
of today, when everyone is squeezed for time, the majority of people are finicky when it comes to placing a 
food order. The customers of today are not only attracted because placing an order online is very 
convenient but also because they have visibility into the items offered, price and extremely simplified 
navigation for the order. </h3>
<br>
<h3 class="text-info">
<em><b>Davao Food Express</b></em> is greatly simplifies the ordering process for both 
the customer and the restaurant. System presents an interactive and up-to-date menu with all available 
options in an easy to use manner. Customer can choose one or more items to place an order which will land 
in the Cart. Customer can view all the order details in the cart before checking out. At the end, customer 
gets order confirmation details. Once the order is placed it is entered in the database and retrieved in pretty
much real time.
</h3>

</div><br>
<?php include 'footer.php' ?>
